#include<stdio.h>
#include "MYSYSCALL.h"
int main()
{
	int x;	
       int input;
	while(1)
	{
	      printf("Enter 1 to getcount \t 2 to reset counter \t 0 to exit \n");
	      scanf("%d", &x);
	      if(!x)
	      	break;
	      else if(x==1)
	      {
	      
	      
	      	printf("Enter \n1 for count of Fork  system call \n2 for count of vFork  system call \n3 for count of Execv  system call \n4 for count  of clone  system call \n");
	       
	       scanf("%d",&input);
	      
	      	if(input>=1 && input<=4)
		printf("%d\n",getCount(input));
		else
		printf("Wrong choice\n");	      
	      	
	      
	      }
	      
	      else if(x==2)
	      {
	      	resetCount();
	      	
	      }
	      else 
	      printf("Invalid choice\n"); 	
	}


}
