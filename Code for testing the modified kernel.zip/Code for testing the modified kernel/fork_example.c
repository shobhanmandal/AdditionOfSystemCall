#include<unistd.h>
#include<stdio.h>
int main()
{
  int i=fork();
  if(i==0)
    printf("\nChild\n");
  else
   {

    printf("\nParent\n");
   }
}
