#include <stdio.h>
#include <sys/syscall.h>
#include <unistd.h>
int  getCount(int I)
{

	int a,b,c,d;
	long int ret_status = syscall(333,&a,&b,&c,&d); // 333 is the syscall number for count
	
	if(ret_status == 0){ 
	
	if(I==1) 
	{
		
		return a;
	}	
	else if( I==2) 
	{
		return b;
	}
		
	else if( I==3) 
	{
		return c;
	}
		
	else if( I==4) 
	{
		
		return d;
	}
	else 
	{
		printf("\nSystem call 'sys_listingCountInfo' DID NOT executed correctly. \n" );
		return -1;
	}
		
		}
	else 
	{
		printf("System call 'sys_listingCountInfo' did not execute as expected\n");
		return -1;
	}	
}
void resetCount()
{

	long int ret_status = syscall(334); // 334 is the syscall number for count
	if(ret_status == 0) 
		printf("\nSystem call 'sys_resetCountInfo' executed correctly.\n Use dmesg to check processInfo\n");
			
	else 
		printf("System call 'sys_resetCountInfo' did not execute as expected\n");

}
